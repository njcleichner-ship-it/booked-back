# BookedBack Quote Follow-Up Kit

A practical follow-up system for solo home-service contractors who send estimates and want a consistent, professional way to stay in touch.

## Product promise

Set up a simple quote-follow-up workflow in about 20 minutes using a spreadsheet, text messages, and email. This kit does not promise guaranteed sales; it provides a repeatable process that reduces forgotten follow-ups.

## Planned v1 contents

1. `quick-start-guide.md` — setup and daily workflow
2. `follow-up-cadence.md` — a respectful 14-day schedule
3. `message-templates.md` — adaptable SMS and email scripts
4. `objection-responses.md` — concise replies to common concerns
5. `lead-tracker.csv` — editable estimate pipeline
6. `personalization-checklist.md` — how to avoid robotic messages

## Principles

- Be helpful, brief, and specific.
- Respect opt-outs and stop contacting anyone who asks.
- Never manufacture urgency or claim unavailable discounts.
- Personalize every message with the customer, project, and next step.
- Keep customer information private.
