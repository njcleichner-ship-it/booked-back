# Respectful 14-Day Quote Follow-Up Cadence

This is a default, not a mandate. Slow down when a customer gives a timeframe, and stop immediately after an opt-out or firm no.

## Day 0 — Send the estimate

Confirm delivery, summarize the scope in one sentence, and invite questions.

## Day 2 — Check receipt

Ask whether the estimate arrived and whether anything needs clarification. Do not push for a decision.

## Day 5 — Offer useful clarification

Address a likely question about scope, timing, materials, preparation, or next steps. Keep it specific to the project.

## Day 9 — Ask about the decision process

Politely ask whether the project is still being considered and whether there is information that would help.

## Day 14 — Close the loop

Explain that you will pause follow-up so you do not crowd their inbox. Leave a clear way to restart the conversation.

## Customer-led timing overrides

- `Check back next month`: schedule the exact requested month; do not run the default cadence meanwhile.
- `Waiting on another decision`: ask when a check-in would be useful.
- `Too expensive`: clarify scope and options without disparaging competitors or inventing discounts.
- `Not interested` or `stop`: mark Do not contact immediately.
- Customer replies: pause automated cadence and respond to what they actually said.

## Optional long-term check-in

Only when appropriate and lawful, send one helpful check-in 30–60 days later if the customer said the project was postponed rather than declined. Do not repeatedly revive silent leads.