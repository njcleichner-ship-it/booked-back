# Honest Objection Responses

Use these as frameworks, not scripts to overpower a customer. Never argue, criticize a competitor, or offer a discount that is not real.

## “The price is higher than expected.”

Thanks for being direct. The estimate includes [specific scope/material/service]. If budget is the main constraint, I can explain which parts are essential and whether there are legitimate scope alternatives. I won’t recommend cutting anything that would make the result unsafe or unreliable.

## “Another quote is cheaper.”

That makes sense to consider. Quotes can differ in scope, materials, preparation, warranty, and scheduling. I’m happy to walk through exactly what mine includes so you can compare like for like. Choose the provider that best fits your needs.

## “We need to think about it.”

Of course. Is there a particular question I can answer, or would you prefer I check back at a specific time?

## “The timing doesn’t work.”

Thanks for letting me know. What timeframe would work better? I can tell you honestly whether we expect availability then, without holding a date unless we formally agree to it.

## “Can you discount it?”

I can review whether a different scope or scheduling option changes the price. I don’t want to reduce quality or invent a discount, so I’ll clearly explain any real tradeoff.

## “We’re postponing the project.”

Understood. Would you like me to check back around [month/date], or would you prefer to contact me when you’re ready?

## “Send references/reviews.”

Certainly. Here are [truthful references, portfolio items, or verified review links]. I can also explain which examples are most similar to your project.

## “Are you insured/licensed?”

Answer only with accurate, current facts and documentation. Never imply a credential you do not hold.

## Firm no

Thanks for letting me know. I’ll close this estimate and stop following up. I appreciate the opportunity.