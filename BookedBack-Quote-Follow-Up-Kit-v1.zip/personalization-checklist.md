# Personalization Checklist

Before sending, confirm:

- [ ] Customer name is correct.
- [ ] Your name and business are clear.
- [ ] The project description is specific.
- [ ] At least one detail reflects the real conversation.
- [ ] Every claim, date, price, and availability statement is true.
- [ ] The message matches the customer's current stage.
- [ ] There is one simple next step.
- [ ] Tone is helpful rather than urgent or manipulative.
- [ ] The customer has not opted out.
- [ ] The channel and contact are appropriate and lawful.
- [ ] Placeholder brackets have all been removed.

## Five-second quality check

Would this message feel useful and respectful if you received it from a contractor? If not, rewrite it before sending.