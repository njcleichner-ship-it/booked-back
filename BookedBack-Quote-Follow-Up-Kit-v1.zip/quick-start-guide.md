# BookedBack Quick-Start Guide

## Set up in 20 minutes

1. Open `lead-tracker.csv` in Excel, Google Sheets, or LibreOffice.
2. Replace the example row with every estimate that is still undecided.
3. For each lead, enter the project, estimate date, last contact, and next follow-up date.
4. Choose the appropriate message from `message-templates.md` and personalize every bracketed field.
5. Spend 10 minutes each workday contacting only leads due that day.
6. Immediately record the contact and schedule the next step.
7. Mark outcomes as Won, Lost, Paused, or No response.

## Suggested statuses

- New inquiry
- Estimate scheduled
- Estimate sent
- Follow-up active
- Paused
- Won
- Lost
- Do not contact

## Daily routine

1. Filter the tracker to `Next Follow-Up Date = today or earlier`.
2. Review notes before writing.
3. Send one relevant, personalized message through the channel the customer used or consented to use.
4. Update Last Contact Date and Follow-Up Stage.
5. Add the next date from the cadence, unless the customer replied or opted out.

## Rules that protect trust

- Follow applicable marketing, privacy, and messaging laws in your jurisdiction.
- Contact only genuine leads or customers with an appropriate relationship or consent.
- Identify yourself and your business clearly.
- Never hide an opt-out or continue after someone asks you to stop.
- Do not use artificial scarcity, invented discounts, or pressure tactics.
- Avoid sensitive customer details in the tracker.

## Personalization formula

A useful follow-up usually contains:

1. The customer's name
2. The specific project
3. One relevant detail from the conversation
4. A simple next step

Example: `Hi Jordan—this is Maya from Clearview Painting. I wanted to check whether you had any questions about the exterior estimate, especially the two-coat option we discussed. Would a quick call Thursday help?`

## Measuring the system

Once a week, count:

- Estimates sent
- Estimates followed up on time
- Replies received
- Jobs won
- Reasons jobs were lost

Use results to improve timing and clarity. Do not assume follow-up caused a sale without evidence.