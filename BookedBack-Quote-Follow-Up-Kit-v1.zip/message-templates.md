# BookedBack Message Templates

Replace every bracketed field. Delete any sentence that is not true. SMS messages should identify the business and remain concise.

## Day 0: estimate delivery

**SMS**
Hi [Name], this is [Your Name] from [Business]. I sent the estimate for [Project]. It covers [short scope detail]. Let me know if you'd like me to clarify anything.

**Email subject:** Your [Project] estimate from [Business]

Hi [Name],

Your estimate for [Project] is attached/linked here: [Link or delivery detail]. It includes [specific scope]. If you want to compare options or clarify any line item, reply here and I’ll help.

Thanks,
[Signature]

## Day 2: confirm receipt

**SMS**
Hi [Name]—[Your Name] from [Business]. Just checking that the [Project] estimate reached you. No rush; I’m happy to answer any questions.

**Email subject:** Did the [Project] estimate come through?

Hi [Name],

I wanted to make sure the estimate I sent on [Date] reached you. Is there any part of the scope, timing, or price you would like clarified?

[Signature]

## Day 5: useful clarification

**SMS**
Hi [Name], one detail that may help as you review the estimate: [truthful project-specific clarification]. Would you like me to explain either option?

**Email subject:** One note about your [Project] estimate

Hi [Name],

As you review the estimate, I wanted to clarify [specific detail]. [One or two useful sentences]. If another approach would fit your priorities better, tell me what matters most and I can explain the available options.

[Signature]

## Day 9: decision check

**SMS**
Hi [Name]—is the [Project] still something you’re considering? If timing, scope, or another question is holding things up, I’m glad to help. If plans changed, that’s completely fine too.

**Email subject:** Any questions before you decide on [Project]?

Hi [Name],

I’m checking whether [Project] is still under consideration. If you are comparing scope, scheduling, or options, I can answer questions without any pressure. If the project is postponed, I can also check back when it is useful for you.

[Signature]

## Day 14: close the loop

**SMS**
Hi [Name], I’ll pause my follow-ups on the [Project] estimate so I don’t crowd your messages. If you want to revisit it later, reply here anytime. Thanks for considering [Business].

**Email subject:** Closing the loop on your [Project] estimate

Hi [Name],

I haven’t heard back, so I’ll pause follow-up for now. If you decide to revisit [Project], reply to this email and I’ll confirm whether scope, pricing, and availability are still current.

Thank you for considering [Business].
[Signature]

## When the customer requests more time

Thanks for letting me know. I’ll make a note to check back [their requested timeframe]. If anything changes before then, you can reach me here.

## After a positive decision

Great—thank you, [Name]. The next step is [accurate next step]. I’ll send [document/details] by [realistic time].

## After choosing someone else

Thanks for letting me know, [Name]. I appreciate the opportunity to quote the work. If you're comfortable sharing, was the decision mainly about timing, scope, price, or something else? No obligation—I use feedback to improve.

## Opt-out acknowledgement

Understood. I’ve marked this so we won’t follow up again. Take care.